using System.ComponentModel.DataAnnotations;

namespace OsLog.Api.DTOs.Auth;

public class ChangePasswordRequestDto
{
    [Required(ErrorMessage = "O e-mail � obrigat�rio.")]
    [EmailAddress(ErrorMessage = "E-mail em formato inv�lido.")]
    [MaxLength(256)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "A senha atual � obrigat�ria.")]
    [MinLength(6, ErrorMessage = "A senha atual deve ter no m�nimo 6 caracteres.")]
    [MaxLength(100)]
    public string SenhaAtual { get; set; } = string.Empty;

    [Required(ErrorMessage = "A nova senha � obrigat�ria.")]
    [MinLength(6, ErrorMessage = "A nova senha deve ter no m�nimo 6 caracteres.")]
    [MaxLength(100)]
    public string NovaSenha { get; set; } = string.Empty;
}
